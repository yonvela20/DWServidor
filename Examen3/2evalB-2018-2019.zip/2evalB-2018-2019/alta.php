<html> 
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
</head>
<body>
<h2>Autobuses ALSA - Alta </h2>

<form>
    <div class='col col-md-2'>
        <label for="destino">Destino</label>
        <input class='form-control' id="destino" name="destino" >
    </div>
    <div class='col col-md-2'>
        <label for="fecha">Fecha</label>
        <input  class='form-control' id="fecha" name="fecha" type="date">
    </div>
    <div class='col col-md-1'>
        <label for="plazas">Plazas</label>
        <input  class='form-control' id="plazas" name="plazas">
    </div>
    <div class='col col-md-2'><br>
        <input type=submit class="btn btn-primary" value="Crear">
    </div>

</form>

</body>
</html>
